
# Remember December 2026 Website

## Run locally

1. Install Node.js
2. Open terminal in this folder
3. Run:

npm install
npm run dev

## Deploy to Vercel

1. Upload this folder to GitHub
2. Connect GitHub repo to Vercel
3. Click Deploy
