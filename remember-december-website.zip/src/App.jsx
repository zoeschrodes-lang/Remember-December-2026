
export default function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <section
        className="relative h-screen bg-cover bg-center flex items-center justify-center"
        style={{
          backgroundImage:
            "linear-gradient(to bottom, rgba(0,0,0,0.55), rgba(0,0,0,0.85)), url('/beach.jpg')",
        }}
      >
        <div className="relative z-10 text-center px-6 max-w-5xl">
          <img
            src="/logo.png"
            alt="Remember December Logo"
            className="w-72 md:w-96 mx-auto mb-8"
          />

          <p className="uppercase tracking-[0.35em] text-red-300 text-sm md:text-base mb-4">
            CRC Summer Vacay 2026
          </p>

          <h1 className="text-5xl md:text-8xl font-black uppercase leading-none mb-6">
            Remember
            <br />
            December
          </h1>

          <div className="inline-block bg-red-600 px-6 py-3 rounded-full text-sm md:text-lg font-bold uppercase mb-8 animate-pulse">
            5 Year Anniversary Celebration
          </div>

          <p className="text-lg md:text-2xl text-gray-200 max-w-3xl mx-auto leading-relaxed mb-10">
            An unforgettable summer experience filled with worship, adventure,
            beach sunsets, evangelism, baptisms, and lifelong memories.
          </p>

          <a
            href="https://links.subprimekings.com/widget/survey/lH0jFR7jofTKojGxW1lJ"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-red-600 hover:bg-red-500 transition-all duration-300 px-10 py-5 rounded-2xl text-lg md:text-xl font-bold shadow-2xl"
          >
            Request More Info
          </a>
        </div>
      </section>

      <section className="py-24 px-6 bg-zinc-950">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-black uppercase mb-4">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {faqData.map((faq, index) => (
              <div
                key={index}
                className="bg-black border border-red-900/40 rounded-3xl p-8"
              >
                <h3 className="text-2xl font-bold text-red-400 mb-4">
                  {faq.question}
                </h3>

                <p className="text-gray-300 text-lg leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-gradient-to-r from-red-700 via-red-600 to-red-700 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-7xl font-black uppercase leading-tight mb-8">
            Secure Your Spot
          </h2>

          <p className="text-lg md:text-2xl text-red-100 mb-10 leading-relaxed">
            Spaces are limited. Request more information and get ready for the
            most unforgettable summer of your life.
          </p>

          <a
            href="https://links.subprimekings.com/widget/survey/lH0jFR7jofTKojGxW1lJ"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-red-700 hover:bg-zinc-100 transition-all duration-300 px-10 py-5 rounded-2xl text-lg md:text-xl font-black"
          >
            Get More Information
          </a>
        </div>
      </section>
    </div>
  )
}

const faqData = [
  {
    question: 'What are the dates for Remember December?',
    answer: 'Remember December will be taking place from 30th Nov – 9 December 2026.',
  },
  {
    question: 'Who can attend Remember December?',
    answer: 'It is open to Matriculants and Students aged 17–25.',
  },
  {
    question: 'How do you secure your spot?',
    answer: 'Click on the link to request more info. Pay your deposit and submit your indemnity form and all other documents to secure your spot.',
  },
  {
    question: 'How much is the cost of the trip?',
    answer: 'Cost for cities will be adjusted per city based on traveling expenses.',
  },
  {
    question: 'Where will we be staying?',
    answer: 'The Wilderness Hotel in Wilderness.',
  },
  {
    question: 'Are all activities included in the price?',
    answer: 'All activities except for one which is a self-paid and chosen activity.',
  },
  {
    question: 'Are all meals included?',
    answer: 'All dinners are included.',
  },
  {
    question: 'Will there be supervision?',
    answer: 'Yes. There will also be opportunities for worship, quiet time, evangelising, water baptism and more.',
  },
]
